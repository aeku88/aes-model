---
configs:
- config_name: prompt_1
  data_files:
  - split: train
    path: 'training_set_segmented - prompt_1.csv'
  - split: valid
    path: 'valid_set_segmented - prompt_1.csv'
---